# changecore 邮寄发票领域知识

## 数据模型层次

| 层次 | 类 | 说明 |
|------|-----|------|
| Biz VO | `ChangeInvoiceVO` | 完整的邮寄发票信息（biz层内部使用） |
| Biz VO | `ChangeVO.invoice` | ChangeVO 持有 ChangeInvoiceVO 引用 |
| Facade DTO | `ChangeInfoDTO` | **无发票字段** — TASK-007 需要添加 |
| Facade DTO | `ChangeExtDTO` | **无发票字段** — TASK-007 需要添加 |

## ChangeInvoiceVO 字段

包路径: `com.ly.flight.intl.changecore.biz.model.vo.common.ChangeInvoiceVO`

| 字段 | 类型 | 说明 |
|------|------|------|
| `invoiceOption` | `Integer` | 邮寄方式(1：纸质凭证 2：电子凭证) |
| `mailState` | `MailStateEnum` | 邮寄状态 |
| `contact` | `String` | 联系人 |
| `contactMobile` | `String` | 联系电话 |
| `provinceName` / `provinceId` | `String` / `Integer` | 省份 |
| `cityName` / `cityId` | `String` / `Integer` | 城市 |
| `districtName` / `districtId` | `String` / `Integer` | 区 |
| `address` | `String` | 详细地址 |
| `email` | `String` | 邮箱地址 |
| `supplier` | `SupplierEnum` | 供应商(1-顺丰，2-EMS，3-天天，4-汇通) |
| `invoiceTitle` | `String` | 发票抬头 |
| `customerIdentifier` | `String` | 纳税人识别号 |
| `creator` | `String` | 创建人 |

## 组装流程

```
ChangeInfoAssembly.assemble()
  → changeInvoiceAssembly.assembly(context)  // 组装邮寄发票信息
  → changeVO.setInvoice(...)                 // 设置到 ChangeVO
```

## Facade 层缺口 (TASK-007)

当前 `ChangeInfoDTO` 和 `ChangeExtDTO`（facade层）没有暴露邮寄发票信息。
TASK-007（reverseauxiliary/changecore）需要在 facade DTO 中新增字段，供 reversesearch 的 `RepeatPriceChangeServiceImpl.hasMailingInvoice()` 使用。

判断逻辑建议：`changeInfoDTO.getExtDTO().hasMailingInvoice()` 或类似 boolean 标记。

## 相关枚举

- `MailStateEnum` — 邮寄状态枚举（包: `com.ly.flight.intl.reversebase.common.enums.postinvoice`）
- `SupplierEnum` — 快递供应商枚举（同包）
